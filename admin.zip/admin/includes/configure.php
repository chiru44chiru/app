<?php
/*
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2003 osCommerce
Released under the GNU General Public License
*/
// Define the webserver and path parameters
// * DIR_FS_* = Filesystem directories (local/physical)
// * DIR_WS_* = Webserver directories (virtual/URL)
define('PRODUCTION_FQDN', 'localhost:8888');
define('PRIVATE_FQDN', 'localhost:8888');
define('FQDN', 'http://localhost:8888');
define('ADMIN_NOTICE_EMAIL', '');
define('HTTP_SERVER', '//'.FQDN); // eg, http://localhost - should not be empty for productive servers
define('HTTPS_SERVER', '//'.FQDN); // eg, https://localhost - should not be empty for productive servers
define('ENABLE_SSL', false); // secure webserver for checkout procedure?
define('HTTP_COOKIE_DOMAIN', FQDN);
define('HTTPS_COOKIE_DOMAIN', FQDN);
define('HTTP_COOKIE_PATH', '/Matrix-oSc/');
define('HTTPS_COOKIE_PATH', '/Matrix-oSc/');
define('DIR_WS_HTTP_CATALOG', '/Matrix-oSc/');
define('DIR_WS_HTTPS_CATALOG', '/Matrix-oSc/');
define('DIR_WS_IMAGES', '//media.cablesandkits.com/');
define('DIR_WS_ICONS', DIR_WS_IMAGES . 'icons/');
define('DIR_WS_INCLUDES', 'includes/');
define('DIR_WS_BOXES', DIR_WS_INCLUDES . 'boxes/');
define('DIR_WS_FUNCTIONS', DIR_WS_INCLUDES . 'functions/');
define('DIR_WS_CLASSES', DIR_WS_INCLUDES . 'classes/');
define('DIR_WS_MODULES', DIR_WS_INCLUDES . 'modules/');
define('DIR_WS_LANGUAGES', DIR_WS_INCLUDES . 'languages/');
//Added for BTS1.0
define('DIR_WS_TEMPLATES', 'templates/');
define('DIR_WS_CONTENT', DIR_WS_TEMPLATES . 'content/');
define('DIR_WS_JAVASCRIPT', DIR_WS_INCLUDES . 'javascript/');
//End BTS1.0
define('DIR_WS_DOWNLOAD_PUBLIC', 'pub/');
define('DIR_FS_CATALOG', '/var/www/html/');
define('DIR_FS_DOWNLOAD', DIR_FS_CATALOG . 'download/');
define('DIR_FS_DOWNLOAD_PUBLIC', DIR_FS_CATALOG . 'pub/');
define('DIR_FS_ADMIN', '/admin/');// absolute path required
define('EMAIL_INVOICE_DIR', 'html_emails/');
define('INVOICE_TEMPLATE_DIR', 'templates/');
// define our database connection
//define('DB_DATABASE', 'reports');
define('USE_PCONNECT', 'false'); // use persistent connections?
define('STORE_SESSIONS', 'mysql'); // leave empty '' for default handler or set to 'mysql'
//define('SUGAR_LOCATION',        'sugar.dfwtek.com');
//define('SUGAR_PASSWORD',        'qwerty');
//define('SUGAR_ADMIN',           'admin');
//define('SUGAR_DB',		'sugar.dfwtek.com');
//define('SUGAR_DB_USERNAME',	'dev');
//define('SUGAR_DB_PASSWORD',	'347Str0k3r');
//define('SUGAR_DATABASE',	'sugarcrm');
$service_environment = [
	'gtm' => [
		'account_id' => 'GTM-543XQD9'
	],
	'ups' => [
		'credentials' => [
			'access_license_number' => '4C7AA73596217470',
			'user_id' => 'cnkdeveloper',
			'password' => 'c@bl3snK1t',
		],
		/*'server' => [
			'name' => 'Production Environment',
			'endpoint' => '',
		],*/
		'server' => [
			'name' => 'Customer Integration Environment',
			'endpoint' => '',
		]
	],
	'fedex' => [
	],
	'salesforce' => [
	]
];
define('AWS_SECRET_ACCESS_KEY', 'PXDYpCYLAnD3TSpCgAXCU3N7slz6GQXUGOPro+RP');
define('AWS_ACCESS_KEY_ID', 'AKIAJKGZJSNRTDMZL6OQ');
?>