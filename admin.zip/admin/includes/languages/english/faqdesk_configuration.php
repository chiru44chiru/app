<?php

if (!defined('TABLE_HEADING_CONFIGURATION_TITLE')) define('TABLE_HEADING_CONFIGURATION_TITLE', 'Title');
if (!defined('TABLE_HEADING_CONFIGURATION_VALUE')) define('TABLE_HEADING_CONFIGURATION_VALUE', 'Value');
if (!defined('TABLE_HEADING_ACTION')) define('TABLE_HEADING_ACTION', 'Action');

if (!defined('TEXT_INFO_EDIT_INTRO')) define('TEXT_INFO_EDIT_INTRO', 'Please make any necessary changes');
if (!defined('TEXT_INFO_DATE_ADDED')) define('TEXT_INFO_DATE_ADDED', 'Date Added:');
if (!defined('TEXT_INFO_LAST_MODIFIED')) define('TEXT_INFO_LAST_MODIFIED', 'Last Modified:');


/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:	FaqDesk
	version:		1.2.5
	date:			2003-09-01
	author:			Carsten aka moyashi
	web site:		www..com

*/
?>
