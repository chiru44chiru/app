#!/bin/bash
set -eu
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
export fly_target=${fly_target:-ck}
echo "Concourse API target ${fly_target}"
echo "Tutorial $(basename $DIR)"
export branchName=$(git branch | grep \* | cut -d ' ' -f2)
pushd "$DIR"
#fly -t ${fly_target} login -n ${fly_target} --concourse-url="https://concourse.olivetech.com"
fly -t ${fly_target} validate-pipeline --config pipeline.yaml
fly -t ${fly_target} set-pipeline -p cables-kits-pipeline -c pipeline.yaml --load-vars-from=credentials.yaml -v branch-version=${branchName} -n
fly -t ${fly_target} unpause-pipeline -p cables-kits-pipeline
fly -t ${fly_target} trigger-job -w -j cables-kits-pipeline/ck-build-feature
popd