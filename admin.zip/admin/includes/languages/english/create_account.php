<?php
/*
 $Id: create_account.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

 The Exchange Project - Community Made Shopping!
 http://www.theexchangeproject.org

 Copyright (c) 2000,2001 The Exchange Project

 Released under the GNU General Public License
*/

if (!defined('NAVBAR_TITLE')) define('NAVBAR_TITLE', 'Create an Account');
if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Add a New Customer');
if (!defined('HEADING_NEW')) define('HEADING_NEW', 'Order Process');
if (!defined('TEXT_ORIGIN_LOGIN')) define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>NOTE:</b></font></small> If you already have an account with us, please login at the <a href="%s"><u>login page</u></a>.');
if (!defined('TEXT_VISITOR_CART')) define('TEXT_VISITOR_CART', '<font color="#FF0000"><b> We want to get your order to you as quickly as possible! We need the following information to process your order efficiently.</b></font>');
if (!defined('TEXT_RETURN_CUSTOMER')) define('TEXT_RETURN_CUSTOMER', '<font color="#FF0000">Already have a profile? Please login!</font>');
if (!defined('NAVBAR_NEW_TITLE')) define('NAVBAR_NEW_TITLE', 'Order Process');
if (!defined('TEXT_PRIVACY')) define('TEXT_PRIVACY', '<font color="#FF0000"><b>Haven\'t bought from us before? Ordering is easy. Start by filling in all required fields, and then clicking the \'continue\' button. </b>');

?>
