brew install wget
wget https://github.com/concourse/concourse/releases/download/v5.5.1/fly-5.5.1-darwin-amd64.tgz
tar -xvf fly-5.5.1-darwin-amd64.tgz
rm -rf fly-5.5.0-darwin-amd64.tgz
sudo mkdir -p /usr/local/bin
sudo mv fly /usr/local/bin
sudo chmod 0755 /usr/local/bin/fly
echo "Fly version is $(fly -v)"