<?php
echo '<pre>';
echo print_r($_GET);
echo '</pre>';
echo 'test';

?>