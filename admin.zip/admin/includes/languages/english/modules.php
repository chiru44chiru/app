<?php
/*
 $Id: modules.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2003 osCommerce

 Released under the GNU General Public License
*/

if (!defined('HEADING_TITLE_MODULES_PAYMENT')) define('HEADING_TITLE_MODULES_PAYMENT', 'Payment Modules');
if (!defined('HEADING_TITLE_MODULES_SHIPPING')) define('HEADING_TITLE_MODULES_SHIPPING', 'Shipping Modules');
if (!defined('HEADING_TITLE_MODULES_ORDER_TOTAL')) define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Order Total Modules');

if (!defined('TABLE_HEADING_MODULES')) define('TABLE_HEADING_MODULES', 'Modules');
if (!defined('TABLE_HEADING_SORT_ORDER')) define('TABLE_HEADING_SORT_ORDER', 'Sort Order');
if (!defined('TABLE_HEADING_ACTION')) define('TABLE_HEADING_ACTION', 'Action');

if (!defined('TEXT_MODULE_DIRECTORY')) define('TEXT_MODULE_DIRECTORY', 'Module Directory:');
?>
