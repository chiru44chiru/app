<?php
/*
 $Id: change_password.php,v 2.0 18:23:35 08/18/06 by Maverick

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2003 osCommerce

 Released under the GNU General Public License
*/

if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Change Customer Password');
if (!defined('SORT_BY')) define('SORT_BY', 'Sort by: ');
if (!defined('SELECT_CUSTOMER')) define('SELECT_CUSTOMER', 'Select Customer: ');
if (!defined('FIRST_NAME')) define('FIRST_NAME', 'First Name');
if (!defined('LAST_NAME')) define('LAST_NAME', 'Last Name');
if (!defined('EMAIL')) define('EMAIL', 'Email');
if (!defined('NEW_PASSWORD')) define('NEW_PASSWORD', 'Enter New Password: ');
if (!defined('CHANGE_PASSWORD')) define('CHANGE_PASSWORD', 'Change Password');
if (!defined('PASSWORD_UPDATED')) define('PASSWORD_UPDATED', '\'s password has been updated!');
if (!defined('CUSTOMER_PASSWORD')) define('CUSTOMER_PASSWORD', '');
?>