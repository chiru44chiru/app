<?php
header('Location: /admin/benefits');
?>