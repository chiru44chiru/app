<?php
// Begin faqdesk
if (!defined('FILENAME_FAQDESK')) define('FILENAME_FAQDESK', 'faqdesk.php');
if (!defined('FILENAME_FAQDESK_CONFIGURATION')) define('FILENAME_FAQDESK_CONFIGURATION', 'faqdesk_configuration.php');

if (!defined('EDITOR_IMAGE')) define('EDITOR_IMAGE', DIR_WS_INCLUDES.'modules/faqdesk/html_editor/editor_images');
// End faqdesk


// Begin faqdesk
if (!defined('TABLE_FAQDESK')) define('TABLE_FAQDESK', 'faqdesk');
if (!defined('TABLE_FAQDESK_DESCRIPTION')) define('TABLE_FAQDESK_DESCRIPTION', 'faqdesk_description');
if (!defined('TABLE_FAQDESK_TO_CATEGORIES')) define('TABLE_FAQDESK_TO_CATEGORIES', 'faqdesk_to_categories');
if (!defined('TABLE_FAQDESK_CATEGORIES')) define('TABLE_FAQDESK_CATEGORIES', 'faqdesk_categories');
if (!defined('TABLE_FAQDESK_CATEGORIES_DESCRIPTION')) define('TABLE_FAQDESK_CATEGORIES_DESCRIPTION', 'faqdesk_categories_description');
if (!defined('TABLE_FAQDESK_CONFIGURATION')) define('TABLE_FAQDESK_CONFIGURATION', 'faqdesk_configuration');
if (!defined('TABLE_FAQDESK_CONFIGURATION_GROUP')) define('TABLE_FAQDESK_CONFIGURATION_GROUP', 'faqdesk_configuration_group');
// End faqdesk
?>
