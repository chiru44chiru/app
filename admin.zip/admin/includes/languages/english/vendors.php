<?php
if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Vendors');
if (!defined('HEADING_TITLE_SEARCH')) define('HEADING_TITLE_SEARCH', 'Search:');

if (!defined('TABLE_HEADING_FIRSTNAME')) define('TABLE_HEADING_FIRSTNAME', 'First Name');
if (!defined('TABLE_HEADING_LASTNAME')) define('TABLE_HEADING_LASTNAME', 'Last Name');
if (!defined('TABLE_HEADING_ACCOUNT_CREATED')) define('TABLE_HEADING_ACCOUNT_CREATED', 'Account Created');
if (!defined('TABLE_HEADING_ACTION')) define('TABLE_HEADING_ACTION', 'Action');

if (!defined('TEXT_DATE_ACCOUNT_CREATED')) define('TEXT_DATE_ACCOUNT_CREATED', 'Account Created:');
if (!defined('TEXT_DATE_ACCOUNT_LAST_MODIFIED')) define('TEXT_DATE_ACCOUNT_LAST_MODIFIED', 'Last Modified:');
if (!defined('TEXT_INFO_DATE_LAST_LOGON')) define('TEXT_INFO_DATE_LAST_LOGON', 'Last Logon:');
if (!defined('TEXT_INFO_NUMBER_OF_LOGONS')) define('TEXT_INFO_NUMBER_OF_LOGONS', 'Number of Logons:');
if (!defined('TEXT_INFO_COUNTRY')) define('TEXT_INFO_COUNTRY', 'Country:');
if (!defined('TEXT_INFO_NUMBER_OF_REVIEWS')) define('TEXT_INFO_NUMBER_OF_REVIEWS', 'Number of Reviews:');
if (!defined('TEXT_DELETE_INTRO')) define('TEXT_DELETE_INTRO', 'Are you sure you want to delete this vendor?');
if (!defined('TEXT_DELETE_REVIEWS')) define('TEXT_DELETE_REVIEWS', 'Delete %s review(s)');
if (!defined('TEXT_INFO_HEADING_DELETE_VENDOR')) define('TEXT_INFO_HEADING_DELETE_VENDOR', 'Delete Vendor');
if (!defined('PLEASE_SELECT')) define('PLEASE_SELECT', 'Select One');

?>
