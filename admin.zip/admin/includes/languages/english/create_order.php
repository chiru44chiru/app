<?php
/*
 $Id: create_order.php,v 1.3 2004/09/08 00:36:41 ccwjr Exp $

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2002 - 2004 osCommerce

 Released under the GNU General Public License

*/
define('HEADING_STEP1', 'STEP 1 - Choose a customer & check their details');

if (!defined('HEADING_CREATE')) define('HEADING_CREATE', 'Check Customer Details');

if (!defined('TEXT_SELECT_CUST')) define('TEXT_SELECT_CUST', 'Select a Customer:');
if (!defined('BUTTON_TEXT_SELECT_CUST')) define('BUTTON_TEXT_SELECT_CUST', 'Select This Customer');
if (!defined('TEXT_OR_BY')) define('TEXT_OR_BY', 'or Customer ID:');
if (!defined('BUTTON_TEXT_CHOOSE_CUST')) define('BUTTON_TEXT_CHOOSE_CUST', 'Select This Customer ID');

?>
