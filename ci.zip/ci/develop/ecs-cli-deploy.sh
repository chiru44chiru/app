COMPOSE_FILE="cables-kits/ci/develop/ecs-dev.compose.yaml"
PROJECT_PREFIX="cables-kits"
DEPLOY_TO="dev"
CLUSTER="Olive-dev"
AWS_ACCESS_KEY_ID=$1
AWS_SECRET_ACCESS_KEY=$2
REGION="us-west-2"
/ecs-cli configure \
          profile --profile-name ck-profile \
          --access-key ${AWS_ACCESS_KEY_ID} \
          --secret-key ${AWS_SECRET_ACCESS_KEY}
/ecs-cli compose \
           --verbose \
           --file ${COMPOSE_FILE} \
           --project-name ${PROJECT_PREFIX}-${DEPLOY_TO} \
           --cluster ${CLUSTER} \
           --region ${REGION} \
           create
/ecs-cli compose \
           --verbose \
           --file ${COMPOSE_FILE} \
           --project-name ${PROJECT_PREFIX}-${DEPLOY_TO} \
           --cluster ${CLUSTER} --region ${REGION} service up  --timeout 10