<div id="popup_dialog_container">
	<div id="popup_dialog" style="display:none">
		<div id="popup_dialog_header" style="background-color:#55F; text-align:right;color:#fff;" ><a href="javascript:void(0);" style="color:#FFF;" onClick="$('popup_dialog').hide();">X&nbsp</a></div>
		<div id="popup_content"></div>
	</div>
</div>
