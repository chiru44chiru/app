<?php
/*
 $Id $

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2002 osCommerce

 Released under the GNU General Public License
*/

if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Access Denied');
if (!defined('NAVBAR_TITLE')) define('NAVBAR_TITLE', 'No Right Permission Access');
if (!defined('TEXT_MAIN')) define('TEXT_MAIN', '&nbsp;Please contact your <b>Webmaster</b> to request <br>&nbsp;more access or if you found any problem.<br>&nbsp;');
if (!defined('TEXT_BACK')) define('TEXT_BACK', 'Back');
?>
