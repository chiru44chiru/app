<?php
/*
 $Id: configuration.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2002 osCommerce

 Released under the GNU General Public License
*/

if (!defined('TABLE_HEADING_CONFIGURATION_TITLE')) define('TABLE_HEADING_CONFIGURATION_TITLE', 'Title');
if (!defined('TABLE_HEADING_CONFIGURATION_VALUE')) define('TABLE_HEADING_CONFIGURATION_VALUE', 'Value');
if (!defined('TABLE_HEADING_ACTION')) define('TABLE_HEADING_ACTION', 'Action');

if (!defined('TEXT_INFO_EDIT_INTRO')) define('TEXT_INFO_EDIT_INTRO', 'Please make any necessary changes');
if (!defined('TEXT_INFO_DATE_ADDED')) define('TEXT_INFO_DATE_ADDED', 'Date Added:');
if (!defined('TEXT_INFO_LAST_MODIFIED')) define('TEXT_INFO_LAST_MODIFIED', 'Last Modified:');
?>
