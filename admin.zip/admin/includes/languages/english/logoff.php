<?php
/*
 $Id $

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2002 osCommerce

 Released under the GNU General Public License
*/

if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Log Off');
if (!defined('NAVBAR_TITLE')) define('NAVBAR_TITLE', 'Log Off');
if (!defined('TEXT_MAIN')) define('TEXT_MAIN', 'You have been successfully logged-off from the <b>Admin</b> area. It is safe to leave the computer now. Click back to relogin');
if (!defined('TEXT_RELOGIN')) define('TEXT_RELOGIN', 're-Login');
?>
