<?php
if (!defined('HEADING_TITLE')) define('HEADING_TITLE', 'Inventory Management');

if (!defined('TABLE_HEADING_NUMBER')) define('TABLE_HEADING_NUMBER', 'No.');
if (!defined('TABLE_HEADING_VIEWED')) define('TABLE_HEADING_VIEWED', 'Viewed');
?>
